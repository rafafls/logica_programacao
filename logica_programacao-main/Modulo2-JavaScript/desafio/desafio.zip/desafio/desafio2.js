function esconder() {
    document.getElementById("texto").style.display = "none";
  }
  
  function mostrar() {
    document.getElementById("texto").style.display = "block";
  }