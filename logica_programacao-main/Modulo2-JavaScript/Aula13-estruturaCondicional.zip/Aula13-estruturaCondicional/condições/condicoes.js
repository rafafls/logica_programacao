let nota1 = 10
let nota2 = 10

let media = (nota1 + nota2)/2

if (media >=7){
    console.log("APROVADO!!!");
} else {
    console.log("REPROVADO!!!");

}